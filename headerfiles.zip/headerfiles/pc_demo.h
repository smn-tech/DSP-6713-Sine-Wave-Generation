/************************************************************
 *
 *  Copyright 2009 by Link Research. ALL RIGHTS RESERVED
 *  This software is provided for demonstration purposes only
 *  and is not guaranteed in any way as to its form or function.
 *  There are no restrictions for its use provided this disclaimer
 *  is included with all distributions of this source code.
 *
 ************************************************************/

		/*	main6713.h	*/
/*********************************************************************

	This file should be included in the main6713.c source file
	
*********************************************************************/	

/* Memory mapped addresses for the UARTs */

#define UART_RBR1		*(volatile int *)0xA0200000
#define UART_THR1		*(volatile int *)0xA0200000
#define UART_DLL1		*(volatile int *)0xA0200000
#define UART_DLM1		*(volatile int *)0xA0200004
#define UART_IER1		*(volatile int *)0xA0200004
#define UART_ISR1		*(volatile int *)0xA0200008
#define UART_FCR1		*(volatile int *)0xA0200008
#define UART_LCR1		*(volatile int *)0xA020000C
#define UART_MCR1		*(volatile int *)0xA0200010
#define UART_LSR1		*(volatile int *)0xA0200014
#define UART_MSR1		*(volatile int *)0xA0200018
#define UART_SPR1		*(volatile int *)0xA020001C

#define UART_RBR2		*(volatile int *)0xA0200400
#define UART_THR2		*(volatile int *)0xA0200400
#define UART_DLL2		*(volatile int *)0xA0200400
#define UART_DLM2		*(volatile int *)0xA0200404
#define UART_IER2		*(volatile int *)0xA0200404
#define UART_ISR2		*(volatile int *)0xA0200408
#define UART_FCR2		*(volatile int *)0xA0200408
#define UART_LCR2		*(volatile int *)0xA020040C
#define UART_MCR2		*(volatile int *)0xA0200410
#define UART_LSR2		*(volatile int *)0xA0200414
#define UART_MSR2		*(volatile int *)0xA0200418
#define UART_SPR2		*(volatile int *)0xA020041C

#define UART_RBR3		*(volatile int *)0xA0200800
#define UART_THR3		*(volatile int *)0xA0200800
#define UART_DLL3		*(volatile int *)0xA0200800
#define UART_DLM3		*(volatile int *)0xA0200804
#define UART_IER3		*(volatile int *)0xA0200804
#define UART_ISR3		*(volatile int *)0xA0200808
#define UART_FCR3		*(volatile int *)0xA0200808
#define UART_LCR3		*(volatile int *)0xA020080C
#define UART_MCR3		*(volatile int *)0xA0200810
#define UART_LSR3		*(volatile int *)0xA0200814
#define UART_MSR3		*(volatile int *)0xA0200818
#define UART_SPR3		*(volatile int *)0xA020081C

#define UART_RBR4		*(volatile int *)0xA0200C00
#define UART_THR4		*(volatile int *)0xA0200C00
#define UART_DLL4		*(volatile int *)0xA0200C00
#define UART_DLM4		*(volatile int *)0xA0200C04
#define UART_IER4		*(volatile int *)0xA0200C04
#define UART_ISR4		*(volatile int *)0xA0200C08
#define UART_FCR4		*(volatile int *)0xA0200C08
#define UART_LCR4		*(volatile int *)0xA0200C0C
#define UART_MCR4		*(volatile int *)0xA0200C10
#define UART_LSR4		*(volatile int *)0xA0200C14
#define UART_MSR4		*(volatile int *)0xA0200C18
#define UART_SPR4		*(volatile int *)0xA0200C1C

#define DC_REG			*(unsigned char*)0x90080001	// daughtercard register in CPLD
#define CE2_CONTROL 			 *(int *)0x01800010

#define DC_INTERRUPT_SOURCE		IRQ_EVT_EXTINT4		// for 6713 DSK, use INT4

#define XMIT_BUF_SIZE	256		// size of UART transmit buffer in bytes
#define RECV_BUF_SIZE	256		// size of UART receive buffer in bytes

#define	DATA_RATE_4800		192
#define	DATA_RATE_9600		96
#define	DATA_RATE_19200		48
#define	DATA_RATE_38400		24
#define	DATA_RATE_57600		16
#define	DATA_RATE_115200	8
#define	DATA_RATE_230400	4
#define	DATA_RATE_460800	2
#define	DATA_RATE_921600	1

/*	function prototypes	*/

void initialize_UART (int, unsigned char);
void delay(long );

int UART_send_byte (int, unsigned char);
int UART_recv_byte (int, unsigned char*);
int UART_send_block (int, unsigned char*,unsigned int);
int UART_recv_block (int, unsigned char*,unsigned int);
unsigned int UART_recv_count(int);
unsigned int UART_xmit_count(int);

/*	Set up transmit and receive buffers and pointers for all 4 channels */

			// channel   1	//
unsigned int uiUART_recv_count1=0, uiUART_xmit_count1=0;
unsigned int uiUART_recv_nextin1=0, uiUART_recv_nextout1=0;
unsigned int uiUART_xmit_nextin1=0, uiUART_xmit_nextout1=0;
unsigned char ucUART_recv_buffer1[RECV_BUF_SIZE];
unsigned char ucUART_xmit_buffer1[XMIT_BUF_SIZE];

			// channel   2	//
unsigned int uiUART_recv_count2=0, uiUART_xmit_count2=0;
unsigned int uiUART_recv_nextin2=0, uiUART_recv_nextout2=0;
unsigned int uiUART_xmit_nextin2=0, uiUART_xmit_nextout2=0;
unsigned char ucUART_recv_buffer2[RECV_BUF_SIZE];
unsigned char ucUART_xmit_buffer2[XMIT_BUF_SIZE];

			// channel   3	//
unsigned int uiUART_recv_count3=0, uiUART_xmit_count3=0;
unsigned int uiUART_recv_nextin3=0, uiUART_recv_nextout3=0;
unsigned int uiUART_xmit_nextin3=0, uiUART_xmit_nextout3=0;
unsigned char ucUART_recv_buffer3[RECV_BUF_SIZE];
unsigned char ucUART_xmit_buffer3[XMIT_BUF_SIZE];

			// channel   4	//
unsigned int uiUART_recv_count4=0, uiUART_xmit_count4=0;
unsigned int uiUART_recv_nextin4=0, uiUART_recv_nextout4=0;
unsigned int uiUART_xmit_nextin4=0, uiUART_xmit_nextout4=0;
unsigned char ucUART_recv_buffer4[RECV_BUF_SIZE];
unsigned char ucUART_xmit_buffer4[XMIT_BUF_SIZE];
